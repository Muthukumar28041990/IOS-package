define(["jquery"], function($) {
    var mljDate = {
     	getMLJDashFormat : function(date){
            date = (typeof date !== "undefined") ? date : new Date();
            var mljDateObj = new Date(date);
            var month = ((mljDateObj.getMonth() + 1).toString()).length === 2 ? (mljDateObj.getMonth() + 1) :'0'+ (mljDateObj.getMonth() + 1);
            var date = (mljDateObj.getDate().toString()).length === 2 ? mljDateObj.getDate() :'0'+ mljDateObj.getDate();
            return mljDateObj.getFullYear()+'/'+month+'/'+date+' ('+weekday[mljDateObj.getDay()]+')';
        },
        //Conversion of datetime to this format YYYY-MM-DD HH:MM:SS
        getMLJLastHourDatetime : function(date){
            date = (typeof date !== "undefined") ? date : new Date();
            var mljDateObj = new Date(date);
            var month = ((mljDateObj.getMonth() + 1).toString()).length === 2 ? (mljDateObj.getMonth() + 1) :'0'+ (mljDateObj.getMonth() + 1);
            var date = (mljDateObj.getDate().toString()).length === 2 ? mljDateObj.getDate() :'0'+ mljDateObj.getDate();
            var hours = mljDateObj.setHours(new Date().getHours() - 1);
            hours = (new Date(hours).getHours().toString()).length === 2 ? new Date(hours).getHours() :'0'+ new Date(hours).getHours();
            var minutes = (mljDateObj.getMinutes().toString()).length === 2 ? mljDateObj.getMinutes() :'0'+ mljDateObj.getMinutes();
            var seconds = (mljDateObj.getSeconds().toString()).length === 2 ? mljDateObj.getSeconds() :'0'+ mljDateObj.getSeconds();
            return mljDateObj.getFullYear() + '-' + month + '-' + date +' '+ hours +':' + minutes +':' + seconds;
        },
        getMLJCurrentDatetime : function(date){
            date = (typeof date !== "undefined") ? date : new Date();
            var mljDateObj = new Date(date);
            var month = ((mljDateObj.getMonth() + 1).toString()).length === 2 ? (mljDateObj.getMonth() + 1) :'0'+ (mljDateObj.getMonth() + 1);
            var date = (mljDateObj.getDate().toString()).length === 2 ? mljDateObj.getDate() :'0'+ mljDateObj.getDate();
            var hours = (mljDateObj.getHours().toString()).length === 2 ? mljDateObj.getHours() :'0'+ mljDateObj.getHours();
            var minutes = (mljDateObj.getMinutes().toString()).length === 2 ? mljDateObj.getMinutes() :'0'+ mljDateObj.getMinutes();
            var seconds = (mljDateObj.getSeconds().toString()).length === 2 ? mljDateObj.getSeconds() :'0'+ mljDateObj.getSeconds();
            return mljDateObj.getFullYear() + '-' + month + '-' + date +' '+ hours +':' + minutes +':' + seconds;
        },        
        getMLJYesterdayStartDatetime : function(date){
            date = (typeof date !== "undefined") ? date : new Date();
            var mljDateObj = new Date(date);
            var date = mljDateObj.setDate(mljDateObj.getDate()-1);
            var month = ((mljDateObj.getMonth() + 1).toString()).length === 2 ? (mljDateObj.getMonth() + 1) :'0'+ (mljDateObj.getMonth() + 1);
            date = (mljDateObj.getDate().toString()).length === 2 ? mljDateObj.getDate() :'0'+ mljDateObj.getDate();
            return mljDateObj.getFullYear() + '-' + month + '-' + date +' 00:00:00';
        },
        getMLJYesterdayEndDatetime : function(date){
            date = (typeof date !== "undefined") ? date : new Date();
            var mljDateObj = new Date(date);
            var date = mljDateObj.setDate(mljDateObj.getDate()-1);
            var month = ((mljDateObj.getMonth() + 1).toString()).length === 2 ? (mljDateObj.getMonth() + 1) :'0'+ (mljDateObj.getMonth() + 1);            
            date = (mljDateObj.getDate().toString()).length === 2 ? mljDateObj.getDate() :'0'+ mljDateObj.getDate();
            return mljDateObj.getFullYear() + '-' + month + '-' + date +' 23:59:59';
        },
        getMLJStartDatetime : function(date){
            date = (typeof date !== "undefined") ? date : new Date();
            var mljDateObj = new Date(date);
            var month = ((mljDateObj.getMonth() + 1).toString()).length === 2 ? (mljDateObj.getMonth() + 1) :'0'+ (mljDateObj.getMonth() + 1);
            var date = (mljDateObj.getDate().toString()).length === 2 ? mljDateObj.getDate() :'0'+ mljDateObj.getDate();
            return mljDateObj.getFullYear() + '-' + month + '-' + date +' 00:00:00';
        },
        getMLJEndDatetime : function(date){
            date = (typeof date !== "undefined") ? date : new Date();
            var mljDateObj = new Date(date);
            var month = ((mljDateObj.getMonth() + 1).toString()).length === 2 ? (mljDateObj.getMonth() + 1) :'0'+ (mljDateObj.getMonth() + 1);
            var date = (mljDateObj.getDate().toString()).length === 2 ? mljDateObj.getDate() :'0'+ mljDateObj.getDate();
            return mljDateObj.getFullYear() + '-' + month + '-' + date +' 23:59:59';
        },
        getMLJCurrentDate : function(date){            
            date = (typeof date !== "undefined") ? date : new Date();
            var mljDateObj = new Date(date);
            var month = ((mljDateObj.getMonth() + 1).toString()).length === 2 ? (mljDateObj.getMonth() + 1) :'0'+ (mljDateObj.getMonth() + 1);
            var date = (mljDateObj.getDate().toString()).length === 2 ? mljDateObj.getDate() :'0'+ mljDateObj.getDate();
            return mljDateObj.getFullYear() + '-' + month + '-' + date;
        },
        getMLJNextDate : function(time){
            var date = mljDate.getMLJCurrentDate(), uploadSyncIntervals = [];
            time = (typeof time !== "undefined") ? time.split(':') : "13:00:00".split(':');
            var mljDateObj = new Date(Date.apply(date));
            var eta_ms = new Date(mljDateObj.getFullYear(), mljDateObj.getMonth(), mljDateObj.getDate()+1, time[0], time[1], time[2]).getTime() - Date.now()
            uploadSyncIntervals.push(eta_ms);
            eta_ms = new Date(mljDateObj.getFullYear(), mljDateObj.getMonth(), mljDateObj.getDate()+1, 13, 0, 0).getTime() - Date.now()
            uploadSyncIntervals.push(eta_ms);
            return uploadSyncIntervals;
        },
        getMLJIsToday : function(date){
            if(date !== undefined) {
	            return new Date().toDateString() === new Date(date).toDateString();
        	}
        	else return false;
        },
        getMLJDiffDatetime : function(startdate){            
            startdate = typeof String(startdate) === "string" ? mljDate.getMLJDateFormat(startdate) : new Date(startdate);            
            startdate.setHours(0);
            startdate.setMinutes(0, 0, 0);
            var mljDateObj = new Date();
            mljDateObj.setHours(0);
            mljDateObj.setMinutes(0, 0, 0);
			var timeDiff = Math.abs(mljDateObj.getTime() - startdate.getTime());
			var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));           
            return diffDays;
        },
        getMLJUserSyncTime : function(batchNo){
        	var syncUploadDatetime = null;
            switch (batchNo){
            	case batchNoMapper['SFDC-User-Batch-1']:
            		syncUploadDatetime = mljDate.getMLJNextDate(batchNoMapper['SFDC-User-Batch-1']);
            	break;
            	case batchNoMapper['SFDC-User-Batch-2']:
            		syncUploadDatetime = mljDate.getMLJNextDate(batchNoMapper['SFDC-User-Batch-2']);
            	break;
            	case batchNoMapper['SFDC-User-Batch-3']:
            		syncUploadDatetime = mljDate.getMLJNextDate(batchNoMapper['SFDC-User-Batch-3']);
            	break;
            	case batchNoMapper['SFDC-User-Batch-4']:
            		syncUploadDatetime = mljDate.getMLJNextDate(batchNoMapper['SFDC-User-Batch-4']);
            	break;
            }
            return syncUploadDatetime;
        },
        getMLJDateFormat : function(datetime){
            if (typeof String(datetime) === "string"){
               if(datetime.indexOf(' ') > 0){
                    datetime = datetime.split(' ');
                    var date = datetime[0].split('-');
                    var time = datetime[1].split(':');
                    return new Date(date[0],parseInt(date[1])- 1,date[2],time[0],time[1],time[2]);
               }
               else{
                    var date = datetime.split('-');
                    return new Date(date[0],parseInt(date[1])- 1,date[2]);
                }
            }
       }
	};
    return mljDate;
});