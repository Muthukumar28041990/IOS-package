define(["jquery", "hellojs", "./common.js", "./authentication.js", "./mljWalkConstants.js", "./mljdbproc.js", "./mljObjectModel.js", "./donation.js","./cordova.service.js", "./clientService.js", "./synchronisation.js","./pedometer.js", "./mljDate.js"], function($, hello, commonModule, authModule, mljdbConstantModule, mljdbproc, mljObjectModel, donationModule,cordovaModule, clientService, synchronisation,pedometerModule,mljDate) {
    console.log("Loading registration.js");
    var registrationModule = {
        userinfo: null,
        userData: null,
        sso: null,
		invocationData : {},
        fileName: "",
        bodyOfAttachment: null,
        initialize: function() {
            this.initHellojs();
            this.regData = null;
            registrationModule.bindEvents();
        },
        initHellojs: function() {
            hello.init({
                'facebook': '1582925782018596',//160981280706879
                'twitter': 'oIrnsqoi4Iw0p6S8KPef06ihO'//eQuyZuECKWPiv3D7E4qdg
            }, {
                redirect_uri: 'http://127.0.0.1/callback.html'
            });
        },
        bindEvents: function() {

            $(document).on("pagebeforeshow", function (e, ui) {
                var currentpage = ui.toPage.prop("id");
                if ((currentpage === "synchronization-settings")) {
                      if(device.platform !="iOS")
                      {                                                 
                        $("#synchronization-settings #googlefit").text("グーグルフィット");
                      }
                }               
            });
			$(document).on("pagecontainerbeforeshow", function (e, ui) {
                var prevpg = ui.prevPage.prop("id");
				 var newPageID = ui.toPage.prop("id");
                if ((prevpg === "settings-home")) {
                      $("#backto").show();
                }
				switch (newPageID) {
                    case "EmailReg":
                         $("#EmailReg #profileImg").click(function(e) {
							cordovaModule.galleryGetPicture(function(uri) {
							registrationModule.fileName = new Date().getTime().toString()+".jpg";
							registrationModule.bodyOfAttachment = uri;
							$("#profileImg").css("background-image", "url(data:image/png;base64," + uri + ")");
							});

						});
                        break;
                    case "synchronization-settings":
                        registrationModule.selectedFitnessSource();
                        break;

                }            });

            $(document).on("click", ".registerBy li", function(e) {
                e.preventDefault();
                var reg = $(this).attr("data-by");
                registrationModule.registerBy(reg);
            })

            $(document).on("click", "#formSubmit", function(e) {
                e.preventDefault();
                registrationModule.emailRegistration();
            });

            $(document).on("click", "#completeReg", function(e) {
                registrationModule.completeRegistration();
            });
            $(document).on("click", "#retainReg", function(e) {
                userObj = {};
                e.preventDefault();
                objdata = $('form#memeberReg').serializeArray();
                $.each(objdata, function(index, obj) {
                    userObj[obj.name] = obj.value;
                });
                commonModule.userInfo.setItem = userObj;
                $(':mobile-pagecontainer').pagecontainer('change', 'terms-of-services.html', {
                    transition: 'slide'
                });                
            });
            $(document).on("click", "#editReg, #backReg", function(e) {
                e.preventDefault();
                if(e.currentTarget !== null && e.currentTarget !== undefined && e.currentTarget.id !== null && e.currentTarget.id !== undefined && e.currentTarget.id === "editReg" && commonModule.userInfo.getItem !== null){
                   commonModule.userInfo.getItem["checkbox-enhanced"] = "on";
                }
                else if(e.currentTarget !== null && e.currentTarget !== undefined && e.currentTarget.id !== null && e.currentTarget.id !== undefined && e.currentTarget.id === "editReg" && commonModule.userInfo.getItem === null){
                    registrationModule.userData.userData["checkbox-enhanced"] = "on";
                    commonModule.userInfo.setItem = registrationModule.userData.userData;
                }
                registrationModule.navigateToRegistration(commonModule.userInfo.getItem, 'registration.html');
            });
            $(document).on("click", "#formLogin", function(e) {
                e.preventDefault();
                registrationModule.emailLogin();
            });

            $(document).off("click","#googlefit").on("click","#googlefit",function(){                
                registrationModule.setFitnessSourceCounter(stepSource[0]);
            });
            $(document).on("click", "#fitbit", function() {
                registrationModule.setFitnessSourceCounter(stepSource[1]); 
            });
            $(document).on("click", "#misfit", function() {
                registrationModule.setFitnessSourceCounter(stepSource[2]);
            });
            $(document).on("click", "#donotset", function() {
                //registrationModule.setSource(stepSource[4], '../dashboard.html');
                $(':mobile-pagecontainer').pagecontainer('change', '../dashboard.html', {
                    transition: 'slide'
                });
            });
           
        },
		selectedFitnessSource:function(){
		registrationModule.sso = JSON.parse(commonModule.storage.getItem("sso"));
		var listItem = $("#synchronization").find("li");
		switch (registrationModule.sso.source) {
                    case "googlefit":
						listItem.eq(0).addClass("selected");
                        break;
                    case "fitbit":
						listItem.eq(1).addClass("selected");
                        break;
					case "misfit":
						listItem.eq(2).addClass("selected");
                        break;
                }
		},
      
        setFitnessSourceCounter: function(source){
            registrationModule.sso = JSON.parse(commonModule.storage.getItem("sso"));
            if (source === registrationModule.sso.source) {
                navigator.notification.alert(alreadyacompaniedsource);
                return;
            }
            if(registrationModule.sso.fitnessSourceSelectedDate === undefined && registrationModule.sso.source === undefined){
                commonModule.updateSSO({
                    fitnessSourceSelectedDate: new Date(),
                    fitnessSourceSelectedCount: 0
                });
                registrationModule.setSource(source,'../dashboard.html');
            }
            else{
                if(mljDate.getMLJIsToday(registrationModule.sso.fitnessSourceSelectedDate)){
                    switch(parseInt(registrationModule.sso.fitnessSourceSelectedCount)){
                        case 0:
                            navigator.notification.confirm(sourcechangewarning,onConfirm,"Information",'Ok,Cancel');
                        break;
                        case 1:
                            commonModule.updateSSO({
                                fitnessSourceSelectedDate: new Date(),
                                fitnessSourceSelectedCount: 2
                            });
                            navigator.notification.alert(sourcechangenotpermit);
                        break;
                        default:
                            navigator.notification.alert(sourcechangenotpermit);
                        break;
                    }
                }
                else{
                    commonModule.updateSSO({
                        fitnessSourceSelectedDate: new Date(),
                        fitnessSourceSelectedCount: 0
                    });
                    registrationModule.setSource(source,'../dashboard.html');
                }
            }
            function onConfirm(index) {
                if(index === 1) {
                    commonModule.updateSSO({
                        fitnessSourceSelectedDate: new Date(),
                        fitnessSourceSelectedCount: 1
                    });
                    registrationModule.setSource(source,'../dashboard.html');
                    return true;
                }
                else {
                    commonModule.updateSSO({
                        fitnessSourceSelectedDate: new Date(),
                        fitnessSourceSelectedCount: 0
                    });
                    return false;
                }
            }
        },
        registerBy: function(reg) {
            switch (reg) {
                case "email":
                    registrationModule.navigateToRegistration(null, 'registration/registration.html');
                    break;
                default:
                    registrationModule.apiLogin(reg);
                    break;
            }
        },
        navigateToRegistration: function(userObj, path) {
            $(':mobile-pagecontainer').pagecontainer('change', path, {
                transition: 'slide'
            });
            if (userObj !== null && userObj !== undefined) {
                $(document).on("pagecontainershow", function(e, ui) {
                    e.preventDefault();
                    var newPageID = ui.toPage.prop("id");
                    if (newPageID.toLowerCase() === "emailreg" && userObj !== null && userObj !== undefined) {
                        $("#regemail").val(userObj.email);
                        userObj.screen_name !== undefined ? $("#regnickname").val(userObj.screen_name) : $("#regnickname").val(userObj.nickname);
                        registrationModule.getURI(userObj.thumbnail).then(function(result) {
                            if(result){
                                registrationModule.bodyOfAttachment = result.split(',')[1];
                                registrationModule.fileName = "default.jpg";
                            }
                            if(registrationModule.bodyOfAttachment !== null && registrationModule.bodyOfAttachment !== undefined)
                                $("#profileImg").css("background-image", "url(data:image/png;base64," + registrationModule.bodyOfAttachment + ")");
                        },function(result){
                            if(registrationModule.bodyOfAttachment !== null && registrationModule.bodyOfAttachment !== undefined)
                                $("#profileImg").css("background-image", "url(data:image/png;base64," + registrationModule.bodyOfAttachment + ")");
                        });
                        $('#EmailReg input:radio[name="gender"]').filter('[value="' + userObj.gender + '"]').prop('checked', true).checkboxradio('refresh');
                        $("#regdob").val(userObj.yob);
                        if(userObj["checkbox-enhanced"] !== undefined) {
                            $("#checkbox-enhanced").prop('checked', true);
                        };
                        userObj = null;
                    }
                });
            }
        },
        emailRegistration: function() {
			var userObj = {},
            storeddeviceID = device.uuid,
            objdata = $('form#memeberReg').serializeArray();
            if (registrationModule.validateForm()) {
                $.each(objdata, function(index, obj) {
                    userObj[obj.name] = obj.value;
                });
                userObj.fileName = registrationModule.fileName;
                userObj.bodyOfAttachment = registrationModule.bodyOfAttachment;
                userObj.source = "EM";
                /*userObj.firstname="";
                userObj.lastname="";*/
                userObj.deviceId = storeddeviceID;
                commonModule.updateSSO({
                    email: userObj.email,
                    deviceId: storeddeviceID,
                    lastUploadSyncToSFDC: new Date(),
                    todayUploadSyncData: 0
                });
                var userArray = [];
                userArray.push(userObj);
                registrationModule.userinfo = {
                    userDTOList: userArray
                };
                registrationModule.userData = {userData : registrationModule.userinfo.userDTOList[0]};
                donationModule.getUserProfile("reg").then(function(result){
                    //console.log(result);
                    if(result !== null && result !== false) {
                        registrationModule.deviceRegister();
                    }
                    else registrationModule.navigateToConfirmReg();
                });
            }
        },
        validateForm: function(page) {
            if(!cordovaModule.connection()) {
                commonModule.toaster({"text":checkConnectivity,"type":"error","timeout":3000, "modal":true});
                return;
            }
            else synchronisation.updateOAuthToken();
            var email = page === 'loginpage' ? $("#email").val() : $("#regemail").val();
            var nickname = page === 'loginpage' ? $("#nickname").val() : $("#regnickname").val();
            var yob = page === 'loginpage' ? $("#yob").val() : $("#regdob").val();
            var radios = document.getElementsByName("gender");
            var iagree = page === 'loginpage' ? true : $("#checkbox-enhanced").prop("checked");

            if (email == '') {
                navigator.notification.alert(emailmandatory);
                return false;
            }
            if (IsEmail(email) == false) {
                navigator.notification.alert(invalidemail);
                return false;
            }
            if (nickname == '') {
                navigator.notification.alert(nicknameMandatory);
                return false;
            }
            if (radioValid() == false) {
                navigator.notification.alert(selectGender);
                // alert("Select the one option");
                return false;
            }
            if (yob == '') {
                navigator.notification.alert(yobMandatory);
                return false;
            }
            if (!yearValidation(yob)) {
                return false;
            }
            if (iagree == false) {
                navigator.notification.alert(pleaseAgreeTerms);
                return false;
            }
            return true;

            /* Validate email address */
            function IsEmail(email) {
                var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
                if (!regex.test(email)) {
                    return false;
                } else {
                    return true;
                }
            }
            /* Validate radio buttons */
            function radioValid() {
                var formValid = false;
                var i = 0;
                while (!formValid && i < radios.length) {
                    if (radios[i].checked) formValid = true;
                    i++;
                }
                if (!formValid) {
                    return formValid;
                } else {
                    return formValid;
                }
            }
			/* Validate year of Birth */
			function yobValid(val){
			var regex = /^(19|20)\d{2}$/;
			if (!regex.test(val)) {
                    return false;
                } else {
                    return true;
                }
			}
			function yearValidation(year) {

  var text = /^[0-9]+$/;
  
    if (year != 0) {
        if ((year != "") && (!text.test(year))) {
            navigator.notification.alert("Please Enter Numeric Values Only");
            return false;
        }

        if (year.length != 4) {
            navigator.notification.alert(invalidYob);
            return false;
        }
        var current_year=new Date().getFullYear();
        if((year < 1900) || (year > current_year))
            {
            navigator.notification.alert(invalidYob);
            return false;
            }
        return true;
    } 
}

        },
        profileImage: function(e) {
            var files = !! event.target.files ? event.target.files : [];
            if (!files.length || !window.FileReader) return;
            if (/^image/.test(files[0].type)) { // only image file
                var reader = new FileReader(); // instance of the FileReader
                registrationModule.fileName = files[0].name; // file name
                reader.readAsDataURL(files[0]); // read the local file
                reader.onloadend = function() { // set image data as background of div
                    registrationModule.bodyOfAttachment = this.result.split(',')[1]; // base64 URI image
                    $("#profileImg").css("background-image", "url(data:image/png;base64," + this.result.split(',')[1] + ")");
                }
            }
        },
        getURI: function(image) {
            var deferred = $.Deferred();
            if(image !== undefined && image !== null){
                var img = new Image();
                img.crossOrigin = 'Anonymous';
                img.onload = function() {
                    var canvas = document.createElement('CANVAS');
                    var ctx = canvas.getContext('2d');
                    var dataURL;
                    canvas.height = this.height;
                    canvas.width = this.width;
                    ctx.drawImage(this, 0, 0);
                    dataURL = canvas.toDataURL();
                    deferred.resolve(dataURL);
                    canvas = null;
                };
                img.src = image;
            }
            else deferred.reject(null);
            return deferred.promise();
        },
        completeRegistration: function() {
            registrationModule.sso = JSON.parse(commonModule.storage.getItem("sso"));
            delete registrationModule.userinfo.userDTOList[0]["checkbox-enhanced"];
            registrationModule.invocationData.url = "/services/apexrest/registrationlogin";
            registrationModule.invocationData.type = "POST";
            registrationModule.invocationData.data = registrationModule.userData;
            var request = clientService.cleintRequest(registrationModule.invocationData);
            request.done(function(msg) {
                if (msg.Status.toLowerCase() === "success") {
                    var profileData = registrationModule.userData.userData;
                    profileData.batchNo = msg.Data !== null && msg.Data.length > 0 ? batchNoMapper[msg.Data[0].batchNo] : batchNoMapper["SFDC-User-Batch-1"];
                    commonModule.updateSSO({batchNo: profileData.batchNo});
                    registrationModule.setProfileData(profileData).then(function(result){
                        if(result) {
                            registrationModule.userAuthorised(msg);
                        }
                    },function(error){
                        registrationModule.userAuthorised(msg);
                    });
                }
                else {
                    navigator.notification.alert(msg.Message.en_US);
                    registrationModule.navigateToRegistration(registrationModule.userData.userData, 'registration.html');
                }
            });
            request.fail(function(error) {
                if(error !== undefined && error !== null){
                    error.responseText = (error.responseText === '' || error.responseText === null || error.responseText === undefined) ? navigator.notification.alert(unknownerror) : navigator.notification.alert(error.responseText);
                }
            });
        },
        userAuthorised: function(msg){
            synchronisation.pollingTimer();
            if(msg.Message.en_US !== existinguser && msg.Message.en_US !== existinguserdifferentdeviceId){
                window.localStorage.setItem("userLogged", "true");
                donationModule.getCampaign();
            }
            else if(msg.Message.en_US === existinguser || msg.Message.en_US === existinguserdifferentdeviceId){                      
                registrationModule.navigateToDashboard();
                pedometerModule.getCurrentWeekData();
            }
            else{
                navigator.notification.alert(msg.Message.en_US);
                registrationModule.navigateToRegistration(registrationModule.userData.userData, 'registration.html');
            }
        },
        navigateToConfirmReg: function(){
            $(':mobile-pagecontainer').pagecontainer('change', 'confirm.html', {
                transition: 'slide'
            });
            $(document).on("pagecontainerbeforeshow", function(event, ui) {
                var newPageID = ui.toPage.prop("id"),gender;
                if (newPageID == "RegConfirm") {
                    if(registrationModule.userData.userData.bodyOfAttachment) $("#profilePic").css("background-image", "url(data:image/png;base64," + registrationModule.userData.userData.bodyOfAttachment + ")");
                    $("#static-txt-email").text(registrationModule.userData.userData.email);
                    $("#static-txt-nickname").text(registrationModule.userData.userData.nickname);
                    gender = (registrationModule.userData.userData.gender == "male")?"男性":"女性";
                    $("#static-txt-gender").text(gender);
                    $("#static-txt-dob").text(registrationModule.userData.userData.yob);
                }
            });
        },
        setGFAuthorization:function(path){
            cordovaModule.requestAuthorization(function(data){
                if(data === undefined || data === null || data !== "OK")
                {
                    navigator.notification.alert("You are not authorized with googlefit");           
                }
                else if(data == "OK")
                {
                    navigator.notification.alert("GoogleFit is activated");              
                }
            });
        },
        setSource:function(value, path){
            registrationModule.sso = JSON.parse(commonModule.storage.getItem("sso"));
            commonModule.updateSSO({prevSource: registrationModule.sso.source, source: value});
            $(':mobile-pagecontainer').pagecontainer('change', path, {
                transition: 'slide'
            });
        },
        /* Login function for registered users
        emailLogin: function() {
            registrationModule.sso = JSON.parse(commonModule.storage.getItem("sso"));
            if (registrationModule.validateForm('loginpage')) {
    			var storeddeviceID = device.uuid,
                    loginObj = {},
                    objdata = $('form').serializeArray();
                $.each(objdata, function(index, obj) {
                    loginObj[obj.name] = obj.value;
                });
                registrationModule.invocationData.url = "/services/apexrest/customerAuthentication";
                registrationModule.invocationData.type = "POST";
                registrationModule.invocationData.data = loginObj;
                commonModule.updateSSO({
                    email: loginObj.email,
                    deviceId: storeddeviceID,
                    lastUploadSyncToSFDC: new Date(),
                    todayUploadSyncData: 0
                });
                window.localStorage.setItem("email", loginObj.email);
                loginObj.deviceId = storeddeviceID;
                commonModule.userInfo.setItem = loginObj;
    			//loginObj.deviceId = storeddeviceID; 
                var request = clientService.cleintRequest(registrationModule.invocationData);
                request.done(function(msg) {
                    if (msg.Status.toLowerCase() === "success") {
                        var profileData = commonModule.userInfo.getItem;
                        profileData.batchNo = msg.Data !== null && msg.Data.length > 0 ? batchNoMapper[msg.Data[0].batchNo] : batchNoMapper["SFDC-User-Batch-1"];
                        commonModule.updateSSO({batchNo: profileData.batchNo});
                        registrationModule.setProfileData(profileData).then(function(result){
                            if(result) {
                                synchronisation.pollingTimer();
                                registrationModule.navigateToDashboard();
								pedometerModule.getCurrentWeekData();
                            }
                        });
                    }
                    else if (msg.ErrorCode === "409")
                    {
                         navigator.notification.alert(msg.Message.en_US);
                    }
                    else {
                        // navigator.notification.confirm(alldatawilllost,
                        //     registrationModule.deviceConfirm,
                        //     "Information",
                        //     'Register,Cancel');
                        registrationModule.deviceRegister();
                    }
                });
                request.fail(function(error) {
                    if(error !== undefined && error !== null){
                        error.responseText = (error.responseText === '' || error.responseText === null || error.responseText === undefined) ? navigator.notification.alert(unknownerror) : navigator.notification.alert(error.responseText);
                    }
                });
            }
        }, */
        apiLogin: function(network) {
            //hello(network).login().then(console.log.bind(console),console.error.bind(console));
            var socialNetwork = hello(network);            
            socialNetwork.login({scope:'email'}).then(function(r) {
                    // Get Profile
                    return socialNetwork.api('me');
            })
            .then(function(data) {
                registrationModule.socialNetworkMemberReg(data, network);
            }, function() {
                console.log(arguments);
            });
        },
        socialNetworkMemberReg: function(memberInfo, network) {
            var userObj = {},
                storeddeviceID = device.uuid;
            $.each(memberInfo, function(index, obj) {
                userObj[index] = obj;
            });
            userObj.screen_name = userObj.screen_name === undefined ? userObj.first_name + ' ' + userObj.last_name : userObj.screen_name;
            userObj.fileName = "";
            userObj.bodyOfAttachment = "";
            userObj.source = network === 'facebook'? "FB":"TW";
            userObj.deviceId = storeddeviceID;
            var userArray = [];
            userArray.push(userObj);
            registrationModule.userinfo = {
                userDTOList: userArray
            };
            registrationModule.navigateToRegistration(userObj, 'registration/registration.html');

        },
        deviceConfirm: function(buttonIndex) {
            if (buttonIndex == 1) {
                registrationModule.deviceRegister();
                return true;
            } else {
                return false;
            }
        },
        deviceRegister: function() {
            registrationModule.sso = JSON.parse(commonModule.storage.getItem("sso"));
            //var deviceId = "ib12345";
            var obj = {
                "email": registrationModule.sso.email,
                "deviceId": device.uuid
            };
            registrationModule.invocationData.url = "/services/apexrest/updateDeviceId";
            registrationModule.invocationData.type = "POST";
            registrationModule.invocationData.data = obj;
            var request = clientService.cleintRequest(registrationModule.invocationData);
            request.done(function(msg) {
                if (msg.Status.toLowerCase() === "success") {
                    var profileData = registrationModule.userData.userData;
                    profileData.batchNo = msg.Data !== undefined && msg.Data !== null && msg.Data.length > 0 ? batchNoMapper[msg.Data[0].batchNo] : batchNoMapper["SFDC-User-Batch-1"];
                    commonModule.updateSSO({batchNo: profileData.batchNo});
                    registrationModule.setProfileData(profileData).then(function(){
                        synchronisation.pollingTimer();
                        registrationModule.navigateToDashboard();
						pedometerModule.getCurrentWeekData();
                        // navigator.notification.alert(msg.Message.en_US, function() {
                        //     registrationModule.navigateToDashboard();
                        // }, "Success");
                    });
                } else {
                    navigator.notification.alert(msg.Message.en_US);
                }

            });
            request.fail(function(error) {
                if(error !== undefined && error !== null){
                    error.responseText = (error.responseText === '' || error.responseText === null || error.responseText === undefined) ? navigator.notification.alert(unknownerror) : navigator.notification.alert(error.responseText);
                }
            });
        },
        navigateToDashboard: function(){
            window.localStorage.setItem("userLogged", "true");
            donationModule.getCampaign().then(function(){
                $.mobile.pageContainer.pagecontainer('change', '../dashboard.html', {
                    reverse: false,
                    changeHash: false
                 });
            });
        },
        setProfileData : function(loginObj){
            var deferred = $.Deferred();
            var registry = mljdbproc.colDefinition(mljdbConstantModule.tables[3].columns);
            var insertQ = 'INSERT INTO '+ mljdbConstantModule.tables[3].name + ' (' + (registry.columnNameColl.join(',')) + ') VALUES ('+ (registry.columnValColl.join(',')) + ')';
            registry.columnVal = [{}];
            registry.columnVal[0] = mljdbproc.mljColMapper(mljObjectModel.userProfile, loginObj);
            registry.columnVal[0].oAuthToken = registrationModule.sso.accessToken;
            registry.columnVal[0].lastUpdatedTime = new Date($.now());
            commonModule.storage.setItem("appRegisteredDate",registry.columnVal[0].lastUpdatedTime);
            var invocationData = {
                tablename: mljdbConstantModule.tables[3].name,
                seed: registry.columnVal[0],
                query: insertQ
            };                    
            $.when(mljdbproc.mljSetDataInDB(invocationData)).then(function(result){
                if(!result){
                    deferred.reject(false);
                    //call common error module
                }
                deferred.resolve(true);
            },function(error){
                deferred.reject(false);
            });
            return deferred.promise();
        }

    };
    return registrationModule;
});