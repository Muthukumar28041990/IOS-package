/**
    @path: js/module/course.js
    @atuthor: Cognizant
    @lastModifiedby: muthukumar
    @Desc: Events and logic for course recording
**/

define(["jquery", "./common.js", "./tutorial.js", "./cordova.service.js","./mljdbproc.js"], function($, commonModule, tutorialModule, cordovaModule,mljdbproc) {
    console.log("Loading course.js");
    var mobinit = $.Deferred();
    var courseModule = {
        tutorialObj: {
            tutorialName: "course-recording-tutorial",
            tutorialId: "#course-recording-tutorial",
            url: "../tutorials/course-record-tutorial.html"
        },
        initialize: function() {
            this.tutorial(this.tutorialObj);
            this.markers=[];
        },
        tutorial: function(options) {
            console.log("tutorial Course")
            // Before Page show event
            $(document).on("pagecontainerbeforeshow", function(e, ui) {
                var newPageID = ui.toPage.prop("id");

                var tut = commonModule.storage.getItem(options.tutorialName);
                if ((newPageID == "course-start") && (!tut)) {
                    courseModule.startTutorial(options);
                } else {
                    courseModule.removeTutorial(options.tutorialId);
                }
            });
            //this.isPedometerAvailable = cordovaModule.isPedometerAvailable();
            
            this.pagecreate();
        },
        createCourseStartPage: function() {
            var self = this;
             
            $(document).on("pageshow", "#course-start", function(e, ui) {                
                $("#loading-indicator").show();
                $("#cameraBtns-container,#courseBtns-pathTaken-container").hide("fast");
                $("#course_record_map").hide("fast");
                //$("course-startBtn-container").show("fast");
                /* var headerHeight = $("#course-start #header").height();
                var mapContainerHeight = (window.innerHeight - 30) - headerHeight;
                $("#course-start #map-container").css("height", mapContainerHeight); */
                localStorage.removeItem("imgDtl");
                localStorage.removeItem("getStepCount");
                localStorage.removeItem("courseImageCount");
                localStorage.removeItem("courseDesc");
                localStorage.removeItem("cameraLocation");
                localStorage.removeItem("locationArr");
                if(window.watchId != null || window.watchId != undefined)
                {
                    navigator.geolocation.clearWatch(window.stepcountWatchIntervalID);    
                }                
                
                //Event :: Get Customer Location via google map
                if (typeof google === 'object' && typeof google.maps === 'object') {
                    courseModule.loadMap("#course-start #map-container #map-context");
                } else {
                    navigator.notification.alert(NetworkConnectionError)
                    $(this).find(".map-container").html("<div>No Internet Connection</div>");
                      $("#loading-indicator").hide();
                }

                $(document).off("click","#course-startBtn").on("click","#course-startBtn",function(){                   
                                                         
                    $("#loading-indicator").show();
                    
                    //Enable the background mode for course recording
                    cordova.plugins.backgroundMode.enable();
                    courseModule.setBackgroundActivity();
                    localStorage.setItem("start",Date.now());
                    cordovaModule.getCurrentLocation(function(position) {
                                                    
                      if(position.coords.accuracy >100)
                         {
                         navigator.notification.confirm(
                            gpsAccuracyError,
                            function(buttonIndex){
                                if(buttonIndex == "1")
                                {
                                   courseModule.saveLocation(position);
                                }
                                else
                                {
                                    $.mobile.pageContainer.pagecontainer('change', '../dashboard.html', {
                                      reverse: false,
                                      changeHash: false
                                     });
                                }
                            }, 
                            gpsErrorTitle,
                            [continueTxt,cancelTxt]);
                         }
                        else
                         {
                             courseModule.saveLocation(position);
                         }
                    });
                        $("#loading-indicator").hide();
                    //$("#course_record_map").hide("fast");
                }); 
                self.courseRecordPage();
            });
        },
       saveLocation:function(position){
            var self = this;
           var Latitude = position.coords.latitude;
           var Longitude = position.coords.longitude;
           var currentLoc = {
               lat: Latitude,
               lng: Longitude
           };
           var locationArr = [];
           locationArr.push(currentLoc);
           var jsonArr = JSON.stringify(locationArr);
           localStorage.setItem("locationArr",jsonArr);
           self.createCourseRecordPage();
           $("#loading-indicator").hide();
           courseModule.courseStartDateTime = new Date();
           $("#course-startBtn-container,#courseBtns-pathTaken-container").hide("fast");
           $("#cameraBtns-container,#course_record_map").show("fast");
           localStorage.setItem("isCourseRecordingAvail","true");
       
       },
        setBackgroundActivity:function(){
            cordovaModule.isBackgroundServiceEnabled(function(isEnabled){
                if(isEnabled)
                    {
                     cordova.plugins.backgroundMode.setDefaults({ text:'Recording the course'});
                     // Enable background mode
                     cordova.plugins.backgroundMode.onactivate = function () {
                        navigator.geolocation.clearWatch(window.locationWatchId);
                        courseModule.updateLocationCount();
                    }
                    cordova.plugins.backgroundMode.ondeactivate = function() {
                        window.clearInterval(courseModule.stepcountWatchIntervalID); 
                        navigator.geolocation.clearWatch(window.locationWatchId);
                    };
                    cordova.plugins.backgroundMode.onfailure = function(errorCode) {
                        console.log("errorCode");
                      navigator.geolocation.clearWatch(window.locationWatchId);
                    };
                } 
            });
            
        },
        courseRecordPage:function(){
               var self = this;
             //On click the stop the course
            $(document).off("click", "#course-start #stop").on("click", "#course-start #stop", function() {
                    //localStorage.setItem("courseStopTime",Date.now());
                    
                     cordova.plugins.backgroundMode.disable();
                    navigator.geolocation.clearWatch(window.locationWatchId);
                    window.clearInterval(window.stepcountWatchIntervalID);
                    localStorage.setItem("stop", Date.now());
                    $("#loading-indicator").show();
                    $("#course-startBtn-container,#cameraBtns-container").hide("fast");
                    $("#courseBtns-pathTaken-container").show("fast");
                        if(device.platform=="iOS")
                        {
                            cordovaModule.stopPedometer();
                        }
                       cordovaModule.getPedometerSteps(function(data){
                              data = (data == null) ? 0 : data;
                             localStorage.setItem("getStepCount",data);    
                             $("#course-start  #courseSteps").text(data); 
                             $("#course-start  #courseKm").text((data/1320).toFixed(2));
                            if(device.platform!="iOS")
                            {
                                cordovaModule.stopPedometer();
                            }
                            cordovaModule.getCurrentLocation(function(position) {
                                $("#loading-indicator").show();
                                var Latitude = position.coords.latitude;
                                var Longitude = position.coords.longitude;
                                var currentLoc = {
                                    lat: Latitude,
                                    lng: Longitude
                                };
                                var locationArr = JSON.parse(localStorage.getItem("locationArr"));
                                locationArr.push(currentLoc);
                                var jsonArr = JSON.stringify(locationArr);
                                localStorage.setItem("locationArr",jsonArr);
                                self.createPathTakenPage();
                                if(device.platform != "iOS")
                                {
                                    cordovaModule.startPedometer();
                                }
                                 cordova.plugins.backgroundMode.disable();
                                 navigator.geolocation.clearWatch(window.locationWatchId);
                                $("#loading-indicator").hide();
                        });
                       });
                                                              
                             
                     localStorage.setItem("isCourseRecordingAvail","false")
            });

                //Get picture when the camera is pressed and image is saved

            $("#course-start").off("click", "#camera").on("click", "#camera", function() {
                   $("#loading-indicator").show();
                    cordovaModule.getCurrentLocation(function(position) {
                         
                        var currentLoc = {
                            lat: position.coords.latitude,
                            lng: position.coords.longitude
                        };
                        //save the location LatLong
                        var cameraLocation = []; 
                        cameraLocation.push(currentLoc);
                        var jsonArr = JSON.stringify(cameraLocation);
                        localStorage.setItem("cameraLocation", jsonArr);

                        var courseImageCount = localStorage.getItem("courseImageCount");
                        if (courseImageCount == null || courseImageCount == undefined || courseImageCount == "") {
                            localStorage.setItem("courseImageCount", 0);
                        }
                        var courseImageCount = parseInt(localStorage.getItem("courseImageCount"));
                        if (localStorage.getItem("courseImageCount") > 9) {
                            navigator.notification.alert(cameraMaxImageErrorMsg);
                            return;
                        } else {
                            cordovaModule.cameraGetPicture(function(uri) {
                                //alert(uri);
                                   $("#loading-indicator").hide();
                                courseImageCount = parseInt(localStorage.getItem("courseImageCount"));
                                var cameraCancelTxt = ""
                                if(device.platform == "iOS")
                                {
                                    cameraCancelTxt= "no image selected.";
                                    cameraCancelTxt2= "has no access to camera";
                                    cameraCancelTxt3= "has no access to assets";
                                }
                                else
                                {
                                    cameraCancelTxt= "Camera cancelled.";
                                    cameraCancelTxt2= "Did not complete!";
                                    cameraCancelTxt3= "Error capturing image.";
                                }
                                if(uri == cameraCancelTxt || uri ==cameraCancelTxt2 || uri ==cameraCancelTxt3)
                                {
                                    $("#loading-indicator").hide();
                                }
                                else
                                {
                                    var contentString = '<div id="content" style="">' +
                                    // '<h3 id="firstHeading" class="firstHeading">Image</h3>'+
                                    '<div id="bodyContent">' +
                                        '<img width="100px" src=\"' + uri + '\"/>' +
                                        '</div></div>';
                                    var imgLocation = JSON.parse(localStorage.getItem("cameraLocation"));
                                    //  imgLocation[0].lng = imgLocation[0].lng+0.002;
                                      // alert(JSON.stringify(imgLocation[0]))
                                    self.createMarker(imgLocation[0], self.map, 'I', contentString);
                                    self.saveImageDetails(uri);
                                    courseImageCount++;
                                    localStorage.setItem("courseImageCount",courseImageCount);
                                }
                                $("#loading-indicator").hide();
                            });
                        }
                      });                
                });

                $("#course-start").off("click","#exit").on("click","#exit", function(e){                   
                    navigator.notification.confirm(
                        NOTIFICATION_CONFIRMATION_EXITCOURSE_TITLE, 
                        function(buttonIndex){ 
                              e.preventDefault();
                            if(buttonIndex == "1")
                            {
                                  e.preventDefault();
                            } 
                            else
                            {
                                $.mobile.pageContainer.pagecontainer('change', '../dashboard.html', {
                                    reverse: false,
                                    changeHash: false
                                });
                            }                           
                        }, 
                        NOTIFICATION_CONFIRMATION_EXIT_COURSE_MESSAGE,
                        [NOTIFICATION_CONFIRMATION_BUTTON1,NOTIFICATION_CONFIRMATION_BUTTON2]);
                }); 
        },
        createCourseRegistrationPage: function() {
            $(document).on("pageshow", "#course-registration", function(e, ui) {

                var prevPage = ui.prevPage.attr('id');
                var savedImages = JSON.parse(localStorage.getItem("imgDtl"));
                var imgViewHtml = "";

                 $("#course-registration #courseTitle").on("input", function(e){
                      // if (String.fromCharCode(e.which).match(/[^A-Za-z0-9_ ]/)) {
                      //   e.preventDefault(); 
                      //  }

                    var regex = /[\u3000-\u303F]|[\u3040-\u309F]|[\u30A0-\u30FF]|[\uFF00-\uFFEF]|[\u4E00-\u9FAF]|[\u2605-\u2606]|[\u2190-\u2195]|\u203B/g;                     
                    if(regex.test(String.fromCharCode(e.which))) {
                         var textlength = $("#courseTitle").val().length;
                         if(textlength > 20)
                         {
                            e.preventDefault();
                            $("#courseTitle").val($("#courseTitle").val().substr(0,20)); 
                         }
                    }
                    else {
                        var textlength = $("#courseTitle").val().length;
                        if(textlength > 20)
                         {
                            e.preventDefault();
                            $("#courseTitle").val($("#courseTitle").val().substr(0,20)); 
                         }
                    }



                });

                /* $(document).off("click","#course-registration #course-thumbnails a img").on("click","#course-registration #course-thumbnails a img", function(e){ 
                    var imagePath = $(this).attr("src");
                    $("#course-registration #full-image img").attr("src",imagePath);
                    $("#loading-indicator").show();
                    if(device.platform=="iOS")
                    {
                        setTimeout(function(){
                            $("#full-image-popup").css({"top": "30%", "left": "5%"});
                            $("#loading-indicator").hide();
                        },1000);
                    }

               });  */
			   $(document).off("click","#course-registration #course-thumbnails img").on("click","#course-registration #course-thumbnails img", function(e){ 
					var imagePath = $(this).attr("src");
					console.log(imagePath);
                    $("#course-registration #full-image img").attr("src",imagePath);
					$(".mask").show();
					$(".popup").show();
					$(document).off("click", "#full-image .close").on("click", "#full-image .close", function(e){
						$(".mask").hide();
						$(".popup").hide();
					});
				}); 
			   

                if(prevPage == "examine-steps")
                {
                    savedImages =[];
                }
                else
                {
                    if(savedImages!= null)
                    {
                         for (var i = 0; i < savedImages.length; i++) {
                                imgViewHtml += '<li><a href="#full-image"  data-rel="popup" data-position-to="window" data-role="button" data-inline="true" data-transition="fade" aria-haspopup="true" aria-owns="popupPhoto" aria-expanded="false" data-rel="popup"><img src="' + savedImages[i] + '"/></a></li>';
                            }
                         $("#course-thumbnails").html(imgViewHtml);
                    }else
                    {
                        savedImages =[];
                         if (savedImages.length == 0) {
                            imgViewHtml = "<h2>No images</h2>"
                        }
                    }
                }
                 $(document).off("click", "#course-registration #courseRegister_ok").on("click", "#course-registration #courseRegister_ok", function() {
                     $("#loading-indicator").show();
                    var courseTitle = $("#courseTitle").val();
                    var courseDesc = $("#Coursecomments-area").val();
                    
                    if (courseTitle == "") {
                        navigator.notification.alert(courseTitleErrorMsg);
                         $("#loading-indicator").hide();
                        e.preventDefault();
                        return;
                    }
                    else {
                        $("#loading-indicator").hide();
                        localStorage.setItem("courseTitle", courseTitle)
                        localStorage.setItem("courseDesc", courseDesc);
                    }
                    var userStepCount = (localStorage.getItem("getStepCount"));
                    var imagePath = localStorage.getItem("imgDtl");
                    var latlng = localStorage.getItem("locationArr");

                   
                     var courseCreatedDate =  new Date().toString();
                     var source = "CourseRecording";
                    if(prevPage != "examine-steps")
                    {
                        // cordovaModule.storeGoogle(courseModule.courseStartDateTime,courseModule.courseStopDateTime,userStepCount,function(data){
                        // navigator.notification.alert("saved to googlefit");
                        //  // $.mobile.pageContainer.pagecontainer('change', '../dashboard.html', {
                        //  //        reverse: false,
                        //  //        changeHash: false
                        //  //     });
                        //   });
                    }                   
                    else{
                        userStepCount = localStorage.getItem("walkMapDistanceSteps");
                        source = "walkMap";
                        imagePath = "";
                    }
                    var query = "INSERT INTO mljCourse (courseName,courseDesc,courseCreatedDate,imagePath,latlng,userStepCount,status,source) VALUES (?,?,?,?,?,?,?,?)";
                    $.when(mljdbproc.query(query, [courseTitle,courseDesc,courseCreatedDate,imagePath,latlng,userStepCount,"A",source])).then(function(result){
                        if(result){
                            if(prevPage == "examine-steps")
                            {
                                $.mobile.pageContainer.pagecontainer('change', 'course-recorded.html?basePrevPage=walkMap', {
                                reverse: false,
                                changeHash: false
                             });
                            }
                            else
                            {
                                $.mobile.pageContainer.pagecontainer('change', 'course-recorded.html?basePrevPage=courseRecord', {
                                    reverse: false,
                                    changeHash: false
                                });
                            }
                            $("#loading-indicator").hide();
                        }
                        else{
                            //show some error message
                            navigator.notification.alert("error occurs, Please try again later");
                        }
                    });
                });
            });
        },
        createPathTakenPage: function() { 
                    $("#loading-indicator").show();
                    var self = this; 
                    var stepsCount = localStorage.getItem("getStepCount");
                    stepsCount = (stepsCount == null) ? 0 : stepsCount;
                    $("#course-start #courseSteps").text(stepsCount);   
                    $("#course-start  #courseKm").text((stepsCount/1320).toFixed(2));
                    self.clearMarkers();
                // store in the steps count value in header

                //Event :: Get Customer Location via google map
                    var coursePath = localStorage.getItem("locationArr");
                    var flightPlanCoordinates = JSON.parse(coursePath);
                    var currentLoc = flightPlanCoordinates[0];
//                    alert(flightPlanCoordinates);
                     var flightPath = new google.maps.Polyline({
                        path: flightPlanCoordinates,
                        geodesic: true,
                        strokeColor: '#1D5922',
                        strokeOpacity: 1.0,
                        strokeWeight: 5
                    });
                    self.map.setCenter(new google.maps.LatLng(currentLoc));
                    flightPath.setMap(self.map); 
                      $("#loading-indicator").hide(); 
        },
        saveImageDetails: function(imgdtl) {
              $("#loading-indicator").show();
            var savedImgDtl = [];
            var savedImg = JSON.parse(localStorage.getItem("imgDtl"));
            if (savedImg == null || undefined || "") {
                savedImgDtl = [];
            } else {
                for (var i = 0; i < savedImg.length; i++) {
                    savedImgDtl.push(savedImg[i]);
                }

            }
            savedImgDtl.push(imgdtl);
            localStorage.setItem("imgDtl", JSON.stringify(savedImgDtl));
            $("#loading-indicator").hide();
        },
        createCourseRecordedPage: function() {
            var self = this;
            $(document).on("pageshow", "#course-recorded", function(e, ui) {
                 $("#loading-indicator").hide();
                var courseTitle = localStorage.getItem("courseTitle");
                var courseDesc = localStorage.getItem("courseDesc");
                if(courseDesc == null)
                {
                    courseDesc = "";
                }
               // $("#line-share").attr("href","http://line.me/R/msg/text/?"+courseDesc);
                $("#line-share").click(function(){ 
                 
                 window.open("https://line.me/R/msg/text/?[Manulife WALK]"+courseTitle+'%0A'+(courseDist/1320).toFixed(2)+" Km /"+courseDist+ "steps"+'%0A'+"を登録しました。", '_system', 'location=no');
                });
                var prevPage = this.baseURI.split("?")[1].split("=")[1];
                // querystring = url.split("?")[1]; /* retruns ?basePrevPage=walkmap */
                // var  prevPageArray= querystring.split("=");
                // var prevPage =  prevPageArray[1];
                // var courseDist=""
                if(prevPage=="walkMap")
                {
                    courseDist = localStorage.getItem("walkMapDistanceSteps");
                }
                else
                {
                    courseDist = localStorage.getItem("getStepCount");
                } 
                $("#course-recorded #heading").text(courseTitle);
                $("#course-recorded #path-travelled").text(courseDesc);
                $("#course-recorded #distanceTravelledSteps").text(courseDist);
                 $("#course-recorded #distance-travelledkm").text((courseDist/1320).toFixed(2));
                var date= commonModule.formatDate(new Date());
                $("#course-recorded #course-taken-date").text(date);
                $(document).off("click", "#twitter-share").on("click", "#twitter-share", function() {
                    cordovaModule.socialShare("twitter", [courseTitle, (courseDist/1320).toFixed(2)+" Km/"+courseDist+" steps" ], function(data) {
                        console.log("twitter share fixed");
                    });
                })
                $(document).off("click", "#facebook-share").on("click", "#facebook-share", function() {
                    cordovaModule.socialShare("facebook", [courseTitle,courseDesc,courseDist+" steps /"+(courseDist/1320).toFixed(2)+" Km"], function(data) {
                        console.log("facebook share fixed");
                    });
                });

                localStorage.removeItem("imgDtl");
                localStorage.removeItem("getStepCount");
                localStorage.removeItem("walkMapDistanceSteps");
                localStorage.removeItem("courseImageCount");
                localStorage.removeItem("courseDesc");
                localStorage.removeItem("cameraLocation");
                localStorage.removeItem("locationArr");
                if(window.watchId != null || window.watchId != undefined)
                {
                    navigator.geolocation.clearWatch(window.watchId);    
                } 
            });
        },
        createCourseRecordPage: function() {
            var self = this; 
                //Event :: Get Customer Location via google map
                
                // Start the pedometer and get steps value
                cordovaModule.isPedometerAvailable(function(isAvail) {
                    if (isAvail) {
                        // Stop the pedometer count 
                        isPedoStarted = localStorage.getItem("isPedoStarted")
                        if (isPedoStarted == "true") {                            
                            
                            cordovaModule.stopPedometer();
                        }
                        //start  the pedometer 
                        cordovaModule.startPedometer();
                         
                    } else {
                        navigator.notification.alert(pedometerErrorMsg);
                    }
                }); 

              courseModule.updateLocationCount();  
                         
        },
        updateLocationCount:function(){
           window.stepcountWatchIntervalID=  setInterval(function(){
                    if(localStorage.getItem("isCourseRecordingAvail") =="true")
                    {
                            if(device.platform !="iOS")
                            {
                                cordovaModule.getPedometerSteps(function(data){
                                    data = (data == null) ? 0 : data;
                                    localStorage.setItem("getStepCount",data);
                                    $("#course-start  #courseSteps").text(data);
                                    $("#course-start  #courseKm").text((data/1320).toFixed(2)); 
                                });
                            }
                    }
                },5000);
                cordovaModule.watchPosition(function(position) {
                    //alert(JSON.stringify(position));
                    var Latitude = position.coords.latitude;
                    var Longitude = position.coords.longitude;
                    var currentLoc = {
                        lat: Latitude,
                        lng: Longitude
                    };
                     if(position.coords.accuracy <100)
                    {
                        var locationArr = JSON.parse(localStorage.getItem("locationArr"));
                        locationArr.push(currentLoc);
                        var jsonArr = JSON.stringify(locationArr);
                        localStorage.setItem("locationArr", jsonArr);
                    }
                    
                });
        },
        pagecreate: function() {
            // On Page show Event for Course start page
            var self = this;
            this.createCourseStartPage();
            //this.createCourseRecordPage();
            //this.createPathTakenPage();
            this.createCourseRegistrationPage();
            this.createCourseRecordedPage();

        },

        createMarker: function(pos, map, title, contentString) {
            var self = this;            
            var marker = new google.maps.Marker({
                position: pos,
                map: map, // google.maps.Map 
                title: title
            });
             map.setCenter(new google.maps.LatLng(pos));
            this.markers.push(marker);
            google.maps.event.addListener(marker, 'click', function() {
                var infowindow = new google.maps.InfoWindow();
                infowindow.setContent(contentString);
                infowindow.open(map, marker);
            });
            return marker;
        },
        loadMap: function(mapContainer) {
            // Getting the current location using cordova geolocation plugin
            var self = this;
            cordovaModule.getCurrentLocation(function(position) {
                //alert(JSON.stringify(position));
                 $("#loading-indicator").show();
                var Latitude = position.coords.latitude;
                var Longitude = position.coords.longitude;
                var currentLoc = {
                    lat: Latitude,
                    lng: Longitude
                }; 
                self.map = new google.maps.Map($(mapContainer)[0], {
                    //self.map = new google.maps.Map(document.getElementById('map-container'), {
                    zoom: 18,
                    center: currentLoc,
                     mapTypeId: google.maps.MapTypeId.ROADMAP

                });

                var contentString = '<div id="content">' +
                    '<div id="bodyContent">' +
                    '<p><b>'+courseRecordingStart+' </b>'
                '</div>' +
                    '</div>';
                self.createMarker(currentLoc, self.map, "", contentString); 
                 $("#loading-indicator").hide();
                });            
            //$("#loading-indicator").hide();
        },
        startTutorial: function(options) {
            tutorialModule.initTutorialCarousel(options);
            $(document).on("click", "#courseok", function(e) {
                e.stopImmediatePropagation();
                e.preventDefault();
                commonModule.storage.setItem(options.tutorialName, "true");
                courseModule.removeTutorial(options.tutorialId);
            });

        },
        clearMarkers:function(){
            for (var i = 0; i < this.markers.length; i++) {
                this.markers[i].setMap(null);
              }
        },
        removeTutorial: function(tutorialId) {
            $(tutorialId).remove();
            $('body').removeClass("overflowH");
        }
    };
    return courseModule;
});