
/**
@path: js/module/walkmap.js
@author:Cts
@Last Updated:
@Desc: Walkmap loading and draw line btw two points.
**/


define(["jquery","./common.js", "./tutorial.js","./cordova.service.js","./mljdbproc.js"], function ($, commonModule, tutorialModule,cordovaModule,mljdbproc) {
    console.log("Loading walkmap.js");
    var mobinit = $.Deferred();
    var previousLocation;
  	var index;
    var lat_pos,
        lng_pos,
        start_pos_coords;
    var walkmapModule = {
        tutorialObj: {
            tutorialName: "walking-map-tutorial",
            tutorialId: "#walkingmap-tutorial",
            url: "../tutorials/walking-map-tutorial.html"
        },    
        initialize: function () {

            // tutorial Initialize
            this.tutorial(this.tutorialObj);
			walkmapModule.bind();
		   var map;
            
            //Getting Id's of the pages navigated
            $(document).on("pagecontainershow", function (event, ui) {
                walkmapModule.newPageID = ui.toPage.prop("id");
                console.log("id:"+ walkmapModule.newPageID);
                if (walkmapModule.newPageID === "examine-steps") { 
                    walkmapModule.initMapStart(walkmapModule.newPageID);
                }
                // else if(walkmapModule.newPageID === "examine-stepsGoal"){
                //     walkmapModule.initMapStartGoal(walkmapModule.newPageID);
                // }
                // else if(walkmapModule.newPageID === "steps-navigation"){
                //     walkmapModule.drawPolyLine();
                // }
                else if(walkmapModule.newPageID === "return-course"){
                 walkmapModule.courseMap();
                }
                if(walkmapModule.newPageID === "viewCourses"){
                   $("#viewCourses #last-updated").change(function () { 
                      var id = $(this).val(); 
                      if(id=="date")
                      {
                         walkmapModule.sortRecommendedCourses("courseCreatedDate");
                      }
                      else if(id=="steps")
                      {
                         walkmapModule.sortRecommendedCourses("userStepCount");
                      }
                      else if(id=="title")
                      {
                         walkmapModule.sortRecommendedCourses("courseName");
                      } 
                  });
        
                    $.ajax({
                        type: 'GET',
                        url: '../data/walkmap.json',
                        dataType: 'json',
                        success: function(data){
                           commonModule.storage.setItem("recommendedCourses", JSON.stringify(data));
                           walkmapModule.sortRecommendedCourses("courseCreatedDate");
                        },
                        error: function(){
                            console.log('error');
                        }
                    });
                    return false;
                }
                else if (walkmapModule.newPageID === "courseDetails"){
                    walkmapModule.showMore();
                }
            });
        },

       sortRecommendedCourses: function(type){
          var JSONarr = JSON.parse(commonModule.storage.getItem("recommendedCourses"));
          var data =  commonModule.sortJson(JSONarr,type, "asc");
           walkmapModule.renderRecommendedCourses(data);
       }, 
       renderRecommendedCourses:function(data){    
            console.log(data);
            walkdata=data;
            console.log(walkdata);
            data=data;
            var output="";
            for (var i in data) {
                output+="<div class='courseData'>" + 
                        "<img src='" + data[i].imagePath[0].src + "'/>" +
                        "<div class='mapDataCourse'><p class='courseCreatedDate'>" + data[i].courseCreatedDate + "</p>" + 
                        "<p class='courseDesc'>" + data[i].courseDesc + "</p>" + 
                        "<p class='userStepCount'>" + data[i].userStepCount + "</p>" + 
                        "<a href='course-details.html' class='show-more'>MORE &raquo;</a></div></div>";
            console.log(output);
            }
            document.getElementById("courseColor").innerHTML=output;
      },
      viewRegisteredCourseList:function(){
         //  on courseList page Load
        $(document).on("pageshow","#registered-courses",function(e,ui){
                var query = "SELECT * from mljCourse ORDER BY courseCreatedDate DESC"; 
				        walkmapModule.renderRegisteredCourses(query);
          // $("#registered-courses").off("click","#sortBy").on("click","#sortBy",function(){
             $("#registered-courses #last-updated").change(function () {
                  var query = "SELECT * from mljCourse ORDER BY courseCreatedDate DESC"; 
                  var id = $(this).val(); 
                  if(id=="date")
                  {
                     query = "SELECT * from mljCourse  ORDER BY courseCreatedDate DESC";
                  }
                  else if(id=="steps")
                  {
                     query = "SELECT * from mljCourse  ORDER BY userStepCount DESC";
                  }
                  else if(id=="title")
                  {
                     query = "SELECT * from mljCourse  ORDER BY courseName";
                  }
                    
                  walkmapModule.renderRegisteredCourses(query);
              });

            });
      } , 

      renderRegisteredCourses:function(query){
        $.when(mljdbproc.query(query, [])).then(function(result){
                  if(result){
                     var rowList = '';
                     if(result.rows.length == 0) { 
                          rowList += '<h2>登録済みのコースはありません</h2>';
                      //  return false;
                      }                      
                     else
                     {
                        for(var i=0; i<result.rows.length; i++) {
                          //rowList += results.rows.item(i).rules + "<br/>";courseName,courseDesc
                          rowList += '  <div class="individual-course">'+
                                  '<div class="course-details">'+
                                '<p class="course-taken-date">'+commonModule.formatDate(result.rows.item(i).courseCreatedDate)+'</p>'+
                                '<p class="path-travelled">'+result.rows.item(i).courseName +"<br>"+result.rows.item(i).courseDesc +'</p>'+
                                '<p class="distance-travelled clearfix"><span>'+((result.rows.item(i).userStepCount)/1320).toFixed(2)+'km /'+result.rows.item(i).userStepCount+'歩</span><span class="rating"></span></p>'+
                                '<a href="individual-course.html?id='+result.rows.item(i).courseId+'" class="more">MORE &raquo;</a>'+
                                '</div>'+
                                '</div> '; 
                        }
                     }
                      
                      $("#registered-courses #course-list .content").html(rowList);
                  }
                  else{
                      //show some error message
                      navigator.notification.alert(registeredCourseErrorMsg);
                  }
              });
      },

		bind: function () { 
            /**view list of registered courses**/
            walkmapModule.viewRegisteredCourseList();
            /***view the registered courses in detail**/
            walkmapModule.viewDetailCourse();
            // on walkmap Page load 
              $(document).on("pageshow", "#examine-steps", function(e, ui) { 
                  /** Once the page is loaded***/
                $("#examine-steps #walkmap-goalBtn-container").hide();
                $("#examine-steps #walkmap-okBtn-container").hide();
                $("#examine-steps #editWalkMapRoute_container").hide();
                $("#examine-steps #walkmap-registerBtn-container").hide();  
                
                $("#walkMapEndPlace,#walkMapStartPlace").focus(function() {
                   $(".course-start-footer").css("position","relative");
                 });
                 
                $("#walkMapEndPlace,#walkMapStartPlace").blur(function() {
                   $(".course-start-footer").css("position","fixed");
                }); 
                  /** Event once the walkmap start button is clicked***/
                  walkmapModule.startWalkmap();                  
                /** Event once the starting point button is clicked***/
                 walkmapModule.goalWalkmap();              
                /** Event for exit walkmap  **/
                walkmapModule.exitWalkRegistration();
                /** Event for the Ok click button***/
                walkmapModule.confirmOK();

                /** WHen the user click the change the route of WalkMap **/
               $("#examine-steps").off("click","#editWalkMapRoute_container #editWalkMap").on("click","#editWalkMapRoute_container #editWalkMap",function(){
                     // $("#examine-steps #walkmap-startBtn-container").show();
                     // $("#examine-steps #walkmap-okBtn-container").hide();
                     // $("#examine-steps #editWalkMapRoute_container").hide();
                     // $("#examine-steps #walkmap-registerBtn-container").hide();
                     // $("#examine-steps #walkmap-goalBtn-container").hide();
                });  

                /**When the user clicks the delete the route of the walking map**/
                walkmapModule.deleteWalkmapPath();
                  
              });
				$(document).on("click", ".show-more", function (e) {
					e.preventDefault();
					console.log($(this).parent().parent('div').index());
					index=$(this).parent().parent('div').index();
					console.log(walkdata[index]);
					$(':mobile-pagecontainer').pagecontainer('change', 'course-details.html', {
						transition: 'slide'
					});
				});
				/* $(document).on("click", "#courseDetails ul li", function () {
					walkmapModule.fullImagePopup();
				}); */
				$(document).off("click","#courseDetails #course-photos img").on("click","#courseDetails #course-photos img", function(e){ 
					var imagePath = $(this).attr("src");
					console.log(imagePath);
                    $("#courseDetails #full-image img").attr("src",imagePath);
					$(".mask").show();
					$(".popup").show();
					$(document).off("click", "#full-image .close").on("click", "#full-image .close", function(e){
						$(".mask").hide();
						$(".popup").hide();
					});
				});  
					

        },

        viewDetailCourse:function(){

           $(document).on("pageshow","#individual-course",function(e,ui){

              // get the id of course from the querystring

                /* $(document).off("click","#individual-course #courseImages a img").on("click","#individual-course #courseImages a img", function(e){ 
                    var imagePath = $(this).attr("src");
                    $("#individual-course #full-image img").attr("src",imagePath);
                    $("#loading-indicator").show();
                    if(device.platform=="iOS")
                    {
                        setTimeout(function(){
                            $("#full-image-popup").css({"top": "30%", "left": "5%"});
                            $("#loading-indicator").hide();
                        },1000);
                    }

               });  */
				$(document).off("click","#individual-course #courseImages img").on("click","#individual-course #courseImages img", function(e){ 
					var imagePath = $(this).attr("src");
					console.log(imagePath);
                    $("#individual-course #full-image img").attr("src",imagePath);
					$(".mask").show();
					$(".popup").show();
					$(document).off("click", "#full-image .close").on("click", "#full-image .close", function(e){
						$(".mask").hide();
						$(".popup").hide();
					});
				});

                var courseID = this.baseURI.split("?")[1].split("=")[1]; 
                var query = "SELECT * from mljCourse where courseId="+courseID;
             $.when(mljdbproc.query(query, [])).then(function(result){
                  if(result){
                   
                     if(result.rows.length == 0) {
                        navigator.notification.alert(viewregisteredCourseErrorMsg);                   
                        return false;
                      }                      
                    else
                    {
                      $("#individual-course #course-taken-date").text(commonModule.formatDate(result.rows.item(0).courseCreatedDate));
                       $("#individual-course #distance-travelled").text(((result.rows.item(0).userStepCount)/1320).toFixed(2)+'km /'+result.rows.item(0).userStepCount+'歩');
                       $("#individual-course #course-title").text(result.rows.item(0).courseName);
                       $("#individual-course #courseComment").text(result.rows.item(0).courseDesc);
                       var images;
                       if(result.rows.item(0).imagePath != "" && result.rows.item(0).imagePath != null)
                       {
                          images = JSON.parse(result.rows.item(0).imagePath); 
                       }
                       else{
                        images=[];
                       }
                       
                       var imageHtml="";
                       for(var i=0; i<images.length; i++)
                        {
                          imageHtml += '<li><a href="#full-image"  data-rel="popup" data-position-to="window" data-role="button" data-inline="true" data-transition="fade" aria-haspopup="true" aria-owns="popupPhoto" aria-expanded="false" data-rel="popup"><img src="' + images[i] + '"/></a></li>';                            
                        }
                      $("#individual-course #courseImages").html(imageHtml);
                    }
                  }
                  else{
                      //show some error message
                      navigator.notification.alert(viewregisteredCourseErrorMsg);    
                  }
              }); 
            });
        },

        deleteWalkmapPath:function(){
           $("#examine-steps").off("click","#editWalkMapRoute_container #deleteWalkMap").on("click","#editWalkMapRoute_container #deleteWalkMap",function(){                     
                     $("#examine-steps #walkmap-okBtn-container").hide();
                     $("#examine-steps #walkmap-registerBtn-container").hide();
                     $("#examine-steps #editWalkMapRoute_container").hide();
                     $("#examine-steps #walkmap-goalBtn-container").hide();
                     $("#examine-steps #walkmap-startBtn-container").show();
                     $("#examine-steps #walkmap_desc").text("出発地点をタップしてSTARTを押してください");
                     $("#walkMapEndPlace").hide();
                     $("#walkMapStartPlace").show();
                     $("#walkMapEndPlace").val("");
                     $("#walkMapStartPlace").val("");
                     walkmapModule.clearMarkers();
                     walkmapModule.directionsDisplay.setMap(null);

                });
        },
        confirmOK:function(){
          $("#examine-steps").off("click","#walkmap-okBtn-container #walkMapOk").on("click","#walkmap-okBtn-container #walkMapOk",function(){
                     $("#examine-steps #walkmap-startBtn-container").hide();
                     $("#examine-steps #walkmap-okBtn-container").hide();
                     $("#examine-steps #editWalkMapRoute_container").hide();
                     $("#examine-steps #walkmap-registerBtn-container").show();
                     $("#examine-steps #walkmap-goalBtn-container").hide();
                      $("#walkMapEndPlace,#walkMapStartPlace").val("");
                      walkmapModule.map.setOptions({draggable: false});
                });
        },
        exitWalkRegistration:function(){
           $("#examine-steps").off("click","#exit").on("click","#exit", function(e){                   
                    navigator.notification.confirm(
                        NOTIFICATION_CONFIRMATION_EXITCOURSE_TITLE, 
                        function(buttonIndex){ 
                              e.preventDefault();
                            if(buttonIndex == "1")
                            {
                                  e.preventDefault();
                            } 
                            else
                            {
                                $.mobile.pageContainer.pagecontainer('change', '../dashboard.html', {
                                    reverse: false,
                                    changeHash: false
                                });
                            }                           
                        }, 
                        NOTIFICATION_CONFIRMATION_EXIT_COURSE_MESSAGE,
                        [NOTIFICATION_CONFIRMATION_BUTTON1,NOTIFICATION_CONFIRMATION_BUTTON2]);
                }); 
        },

        goalWalkmap:function(){
          $("#examine-steps").off("click","#walkmap-goalBtn-container #walkmapgoal").on("click","#walkmap-goalBtn-container #walkmapgoal",function(){
                       var input = $("#walkMapEndPlace")[0];
                       //walkmapModule.createSearchBox(input);
                       var walkMapEndPlace = $("#walkMapEndPlace").val();
                      if(walkMapEndPlace == "")
                      {
                        navigator.notification.alert(walkMapDestinationError);
                        return;
                      }
                      else
                      {
                         walkmapModule.drawPolyLine();
                         walkmapModule.clearMarkers();
                         walkmapModule.directionChange();
                        $("#walkMapStartPlace,#walkMapEndPlace").hide();
                      }
                      $("#examine-steps #walkmap-startBtn-container").hide();
                      $("#examine-steps #walkmap-goalBtn-container").hide();
                      $("#examine-steps #walkmap-okBtn-container").show();
                      $("#examine-steps #walkmap-registerBtn-container").hide();
                      $("#examine-steps #editWalkMapRoute_container").show();  
                        
                      
                  });

        },
        startWalkmap:function(){
          $("#examine-steps").off("click","#walkmap-startBtn-container #startBtn").on("click","#walkmap-startBtn-container #startBtn",function(){
                      var input = $("#walkMapEndPlace")[0];
                      $("#walkMapEndPlace").show("");
                      
                       var walkMapStartPlace = $("#walkMapStartPlace").val();
                      if(walkMapStartPlace == "")
                      {
                        navigator.notification.alert(walkMapSourceError);
                        return;
                      }
                      else
                      {
                        $("#walkMapStartPlace").hide();
                        $("#walkMapEndPlace").show();
                        walkmapModule.createSearchBox(input);
                        walkmapModule.clearMarkers(); 
                      }
                      
                      $("#examine-steps #walkmap-startBtn-container").hide();
                       $("#examine-steps #walkmap-okBtn-container").hide();
                       $("#examine-steps #walkmap-registerBtn-container").hide();
                      $("#examine-steps #walkmap-goalBtn-container").show();
                      $("#examine-steps #editWalkMapRoute_container").hide();  

                      $("#walkMap_record_map #walkmap_desc").text("到着地点をタップしてGOALを押してください");
                      
                       
                });
        },

        tutorial: function (options) {

            // Before Page show event
            $(document).on("pagecontainerbeforeshow", function (e, ui) {
                var newPageID = ui.toPage.prop("id");
                var tut = commonModule.storage.getItem(options.tutorialName);
                if ((newPageID == "strolling-map") && (!tut)) {
                    walkmapModule.startTutorial(options)
                } else {
                    //walkmapModule.removeTutorial(options.tutorialId);
                }
            });
        },
        startTutorial: function (options) {
            tutorialModule.initTutorialCarousel(options);
            $(document).on("click", "#walkok", function (e) {
                e.stopImmediatePropagation();
                e.preventDefault();
                commonModule.storage.setItem(options.tutorialName, "true");
                walkmapModule.removeTutorial(options.tutorialId);
            });
        },
        removeTutorial: function (tutorialId) {
            $(tutorialId).remove();
            $('body').removeClass("overflowH");
        },
        loadMap: function(mapContainer) {
            // Getting the current location using cordova geolocation plugin
            var self = this;
            cordovaModule.getCurrentLocation(function(position) {
                //alert(JSON.stringify(position));
                 $("#loading-indicator").show();
                var Latitude = position.coords.latitude;
                var Longitude = position.coords.longitude;
                var currentLoc = {
                    lat: Latitude,
                    lng: Longitude
                }; 
                walkmapModule.map = new google.maps.Map(mapContainer, {
                    //self.map = new google.maps.Map(document.getElementById('map-container'), {
                    zoom: 17,
                    center: currentLoc,
                     mapTypeId: google.maps.MapTypeId.TERRAIN

                });  
                  var input = $("#walkMapStartPlace")[0];
                walkmapModule.createSearchBox(input);
                 $("#loading-indicator").hide();
             });            
           
        },

        createSearchBox:function(input){
             // adding a search box
              
                walkmapModule.searchBox = new google.maps.places.SearchBox(input);
                walkmapModule.map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);

                walkmapModule.searchboxEvents(input);

                
        },

        searchboxEvents:function(input){
            // Bias the SearchBox results towards current map's viewport.
                walkmapModule.map.addListener('bounds_changed', function() {
                    walkmapModule.searchBox.setBounds(walkmapModule.map.getBounds());
                });
        
            // [START region_getplaces]
            // Listen for the event fired when the user selects a prediction and retrieve
            // more details for that place.
            walkmapModule.searchBox.addListener('places_changed', function() {
                var places = walkmapModule.searchBox.getPlaces();
                previousLocation = places;

                if (places.length == 0) {
                  return;
                }
               walkmapModule.createMarker(places,input);
           });
                // Clear out the old markers.
                
        },
        clearMarkers:function(){
            walkmapModule.markers.forEach(function(marker) {
                  marker.setMap(null);
                });
        },
        createMarker:function(places,input){
            var markers = [];
              markers.forEach(function(marker) {
                  marker.setMap(null);
                });
                markers = [];

                // For each place, get the icon, name and location.
                var bounds = new google.maps.LatLngBounds();
                places.forEach(function(place) {
                  var icon = {
                    url: place.icon,
                    size: new google.maps.Size(71, 71),
                    origin: new google.maps.Point(0, 0),
                    anchor: new google.maps.Point(17, 34),
                    scaledSize: new google.maps.Size(25, 25)
                };

                //Create a marker for each place.
                markers.push(new google.maps.Marker({
                    map: walkmapModule.map, 
                    title: place.name,
                    position: place.geometry.location
                }));
               walkmapModule.markers= markers
                lat_pos = place.geometry.location.lat();
                lng_pos = place.geometry.location.lng();
                if($($(input)[0]).attr("id") ==="walkMapStartPlace" ){
                //if(walkmapModule.newPageID === "examine-steps"){
                    start_pos = {
                        lat_pos:lat_pos,
                        lng_pos:lng_pos
                    };
                    commonModule.storage.setItem("walkmap_start_pos", JSON.stringify(start_pos));
                    commonModule.storage.setItem("walkmap_start_lat_pos", start_pos.lat_pos);
                    commonModule.storage.setItem("walkmap_start_lng_pos", start_pos.lng_pos);
                }
                else   if($($(input)[0]).attr("id") ==="walkMapEndPlace" ){
                    end_pos = {
                        lat_pos:lat_pos,
                        lng_pos:lng_pos
                    };
                      commonModule.storage.setItem("walkmap_end_pos", JSON.stringify(end_pos));
                    //commonModule.storage.setItem("end_pos", end_pos);
                }
                //Finding coordinate position of marker

                if (place.geometry.viewport) {
                    // Only geocodes have viewport.
                bounds.union(place.geometry.viewport);
                  } else {
                    bounds.extend(place.geometry.location);
                  }
                });
                walkmapModule.map.fitBounds(bounds);
              
        },
        initMapStart: function (newPageID) { 

            /* var headerHeight = $("#examine-steps #mapHeader").height();
            var mapContainerHeight = (window.innerHeight - 30) - headerHeight;
            $("#examine-steps #map-container").css("height", mapContainerHeight); */

            var mapID = document.getElementById("map-context");
             //For setting up map
              //Event :: Get Customer Location via google map
                if (typeof google === 'object' && typeof google.maps === 'object') {
                       $("#loading-indicator").show();
                    walkmapModule.loadMap(mapID); 
                    //var map = new google.maps.Map(mapID, mapOptions);
                } else {
                    navigator.notification.alert(NetworkConnectionError)
                    $(this).find("#examine-steps .map-container").html("<div>No Internet Connection</div>");
                } 
             
        },
        updateStepsAfterDragged: function(result){ 
            var total = 0;
            var myroute = result.routes[0];
            for (var i = 0; i < myroute.legs.length; i++) {
              total += myroute.legs[i].distance.value;
            } 
            var dist = (total/ 1000).toFixed(2);
            var dist_steps = Math.round(dist*1312);
            var dist_text = dist+"km/ "+dist_steps+"歩";
            // Displaying the distance in division
            localStorage.setItem("walkMapDistanceSteps",dist_steps);
            $('#walkMap_record_map #walkmap_desc').text(dist_text);  
        },
        drawPolyLine: function(){
             var walkmap_start_pos = JSON.parse(commonModule.storage.getItem("walkmap_start_pos"));
              var walkmap_end_pos = JSON.parse(commonModule.storage.getItem("walkmap_end_pos")); 

            walkmapModule.directionsDisplay = new google.maps.DirectionsRenderer({
                polylineOptions: {
                    strokeColor: "#16754D",
                    strokeWeight:7
                },
                draggable:true
            });
            var directionsService = new google.maps.DirectionsService;
            walkmapModule.directionsDisplay.addListener('directions_changed', function() {
             // walkmapModule.updateStepsAfterDragged(directionsDisplay.getDirections());
              walkmapModule.updateStepsAfterDragged(walkmapModule.directionsDisplay.getDirections());
            });
            walkmapModule.directionsDisplay.setMap(walkmapModule.map);

            // Direction Service route function
            directionsService.route({
                origin: {lat: walkmap_start_pos.lat_pos, lng: walkmap_start_pos.lng_pos},  // Origin.
                destination: {lat: walkmap_end_pos.lat_pos, lng: walkmap_end_pos.lng_pos},  // Destination
                provideRouteAlternatives : true,
                travelMode: google.maps.TravelMode["WALKING"]

              }, function(response, status) {
                console.log(response);
                if (status == google.maps.DirectionsStatus.OK) {
                  walkmapModule.directionsDisplay.setDirections(response);
                } else {
                  navigator.notification.alert('Directions request failed due to ' + status);
                }
            });  

            //Calculating distance between two points
            var p1 = new google.maps.LatLng(start_pos.lat_pos,start_pos.lng_pos);
            var p2 = new google.maps.LatLng(end_pos.lat_pos, end_pos.lng_pos);
            var dist = (google.maps.geometry.spherical.computeDistanceBetween(p1, p2) / 1000).toFixed(2);
            var dist_steps = Math.round(dist*1312);
            var dist_text = dist+"km/ "+dist_steps+"歩";
            // Displaying the distance in division
            localStorage.setItem("walkMapDistanceSteps",dist_steps);
            $('#walkMap_record_map #walkmap_desc').text(dist_text);    
        },
        directionChange:function(){
            walkmapModule.directionsDisplay.addListener('directions_changed', function(data){
            console.log(walkmapModule.directionsDisplay.directions)
          });
        },
		/* fullImagePopup : function(){
			//image=$(this).find('img').attr('src');
			console.log($(this));
			$('#full-image img').attr('src',image);
			var height = $( window ).height() - 60 + "px";
			var width = $( window ).width() * 0.9;
			$( "#full-image img" ).css( "height", height );
			$( "#full-image img" ).css( "width", width );
		}, */
        showMore : function(){
            var output="";
            output+="<div class='courseData'>" +
                    "<div class='mapDataCourse'><p class='courseCreatedDate'>" + walkdata[index].courseCreatedDate + "</p>" + 
                    "<p class='courseDesc'>" + walkdata[index].courseDesc + "</p>" + 
                    "<p class='userStepCount'>" + walkdata[index].userStepCount + "</p>" + 
                    "</div></div>";
			output+="<div class='comments'><h3>COMMENT</h3><p>"+ walkdata[index].Comment +"</p></div>";
            output+="<div id='course-photos' class='clearfix'><h4>このコースの写真</h4>" +
                    "<ul class='clearfix collage'>";
            for (var i in walkdata[index].imagePath[1].src){
                output+="<li><a href='#full-image' data-rel='popup'><img src='" + walkdata[index].imagePath[1].src[i] + "'/></a><p class='image-desc'>" + walkdata[index].imagePath[1].desc[i] + "</p></li>";
            }
            output+="</ul></div>";
            console.log(output);
            document.getElementById("course-details").innerHTML=output;
        },
        courseMap : function(){
            var coord_length=walkdata[index].latlng.length;
            var stepCount = walkdata[index].userStepCount.split("km");
            $("#recommedKm").text(stepCount[0]);
            var stepCountinSteps = parseInt(stepCount[0]).toFixed(2);
            var dist_steps = Math.round(stepCountinSteps*1312);
            $("#recommedSteps").text(dist_steps);

			var mapOptions = {
                zoom: 10,
                center: {
                    lat: parseFloat(walkdata[index].latlng[0].lat),
                    lng: parseFloat(walkdata[index].latlng[0].lng)
                },
                mapTypeId: google.maps.MapTypeId.TERRAIN
            };
			var waypts = [];
			for (var i = 1; i < coord_length; i++) {
				waypts.push({
					location: new google.maps.LatLng(parseFloat(walkdata[index].latlng[i].lat),
							parseFloat(walkdata[index].latlng[i].lng)),
					stopover: false
			  });
			}
            var mapID = document.getElementById("map-context");
             //For setting up map
            var map = new google.maps.Map(mapID, mapOptions);
            var coord_pts = [
                {
                    lat: parseFloat(walkdata[index].latlng[0].lat),
                    lng: parseFloat(walkdata[index].latlng[0].lng)
                },
                {
                    lat: parseFloat(walkdata[index].latlng[coord_length-1].lat),
                    lng: parseFloat(walkdata[index].latlng[coord_length-1].lng)
                }
            ];
           // For marker on a position on the map
            var directionsDisplay = new google.maps.DirectionsRenderer({
                polylineOptions: {
                    strokeColor: "#19784f"
                },
                draggable: false,
            });
            var directionsService = new google.maps.DirectionsService;

            directionsDisplay.setMap(map);

            // Direction Service route function
            directionsService.route({
                origin: {
                    lat:  parseFloat(walkdata[index].latlng[0].lat),
                    lng: parseFloat(walkdata[index].latlng[0].lng)
                },  // Origin.
                destination: {
                    lat: parseFloat(walkdata[index].latlng[coord_length-1].lat),
                    lng: parseFloat(walkdata[index].latlng[coord_length-1].lng)
                },  // Destination
                provideRouteAlternatives : true,
                // Note that Javascript allows us to access the constant
                // using square brackets and a string value as its
                // "property."
                travelMode: google.maps.TravelMode["WALKING"],
				waypoints: waypts

              }, function(response, status) {
                console.log(response);
                if (status == google.maps.DirectionsStatus.OK) {
                  directionsDisplay.setDirections(response);
                } else {
                  navigator.notification.alert('Directions request failed due to ' + status);
                }
            });         
        }
    };

    function markerInitiate(locationPre,markers,map,newPageID) {
        var places = locationPre;

        if (places.length == 0) {
          return;
        }

        // Clear out the old markers.
        markers.forEach(function(marker) {
          marker.setMap(null);
        });
        markers = [];

        // For each place, get the icon, name and location.
        var bounds = new google.maps.LatLngBounds();
        places.forEach(function(place) {
          var icon = {
            url: place.icon,
            size: new google.maps.Size(71, 71),
            origin: new google.maps.Point(0, 0),
            anchor: new google.maps.Point(17, 34),
            scaledSize: new google.maps.Size(25, 25)
        };

        //Create a marker for each place.
        markers.push(new google.maps.Marker({
            map: map,
            icon: icon,
            title: place.name,
            position: place.geometry.location
        }));
        
        lat_pos = place.geometry.location.lat();
        lng_pos = place.geometry.location.lng();

        if(newPageID === "examine-steps"){
            start_pos = {
                lat_pos:lat_pos,
                lng_pos:lng_pos
            };
            commonModule.storage.setItem("start_pos", start_pos);
        }
        else if(newPageID === "examine-stepsGoal"){
            end_pos = {
                lat_pos:lat_pos,
                lng_pos:lng_pos
            };
            commonModule.storage.setItem("end_pos", end_pos);
        }
        //Finding coordinate position of marker

        if (place.geometry.viewport) {
            // Only geocodes have viewport.
        bounds.union(place.geometry.viewport);
          } else {
            bounds.extend(place.geometry.location);
          }
        });
        map.fitBounds(bounds);
    }
    return walkmapModule;
});