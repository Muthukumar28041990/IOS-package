/** 
    @path: js/module/string-define.js 
    @atuthor: Cognizant 
    @lastModifiedby: muthukumar 
    @Desc: variable declaration 
**/ 
var NOTIFICATION_CONFIRMATION_EXITCOURSE_TITLE = "Do we want to exit this course without registration"; 
var NOTIFICATION_CONFIRMATION_EXIT_COURSE_MESSAGE = "登録せずに閉じる"; 
var NOTIFICATION_CONFIRMATION_BUTTON1 = "キャンセル"; 
var NOTIFICATION_CONFIRMATION_BUTTON2 = "閉じる"; 
var NetworkConnectionError = "接続にエラーが発生しました。"; //"Network error"; 
var doNotSet_Jp = "今は設定しない"; 
var doNotSet_en = "Do not set now"; 
var SFDCURL = 'https://login.Salesforce.com/services/oauth2/token'; // Prod Url 
//var SFDCURL = 'https://test.salesforce.com/services/oauth2/token'; // UAT url 
var NetworkConnection = "インターネットに接続できません。"; //"No internet connection available!"; 
var googlefitNotAvailable = "この携帯にフィットネスソースがありません、MisFit または Fitbit　を利用してください。"; 
var stepSource = ['googlefit', 'fitbit', 'misfit', 'healthkit', 'donotset']; 
var usernotmappedwithfitnesssource = "フィットネスソースを設定してください。"; //"Please update the fitness source on the settings"; 
var usernotregisteredwithmisfit = "Please register with misfit"; 
var usernotregisteredwithfitbit = "Please register with fitbit"; 
var campaignExpired = "登録しようとしているキャンペーンは終了しています。"; //"Campaign you trying to register is already expired!"; 
var oAuthInterval = 1000 * 60 * 60 * 5; 
var dashboardInterval = 1000 * 60 * 60; 
var getSourceInterval = 1000 * 60 * 10; 
var networkconnectivity = 10000; 
var uploadSyncInterval = 1000 * 60 * 1; 
var weekday = ["日", "月", "火", "水", "木", "金", "土"];//["Sun", "Mon", "Tue", "Wed", "Thur", "Fri", "Sat"]; 
var alldatawilllost = "新しい機種で登録してよろしいですか。確認を押すとすべてのデータが失われます。"; //"Are you sure to register with the new device? Please press confirm to loose all data."; 
//var enCryptData = "U2FsdGVkX1+nwq9uX7cmiaD2DB5oMO7q47DEsmpQ0RNlHkL+rrZPcnP3lHZ00tvIp2p3bSP9PjKPKCNXsY5YOng9qWqldlYjYvKJH1ZgHRZothqvSiCQu62+nJ3YVSJbEzhALFob9+plyqLT76tvfCTt6JC1XYKZmq60hj1l7H9k/D1EDRhBWlF+hqjnLvb9OB6zTUjXYberd7PD7MiLAK3QWQnZ6PnqzIzWRsCI225y7HQzCFuR2jy0qdqzswCNU5fFUzoPaCSwM40UDVMzw4RtaA1SwbOGaq4UBeZJOnvyBfudsKEP9mHMBHkpUB2t";// UAT encrypt 
var enCryptData = "U2FsdGVkX1+WoQiwlOGpLrouVr5rI/YXWULFOo3HygS3FiUqVRUyaOF1udsL8RWBBwCevobv2jUgm8DkyIYKjv2biPbddY/8QFKDVQJuMKgOeKbgabEowpbRNM1jQo28LQORsC0WHWFHtn8g1dV8H+US5Ym8v5bG0noGaTqRR7SXvh5mTpsfxAyDrQjAF/glfGRbEBoxOeilEGWjacp+QXt9hGFVMx1rCldtIhI8ZfWH+CEfwJv3Dxw11KNxLAudrC9TJZd8Fhf+xXLMzaqLpNDOd06U4k3GzPTMvH1icP0=";// Prod encrypt 
var batchNoMapper = { 
    "SFDC-User-Batch-1": "1:0:0", 
    "SFDC-User-Batch-2": "1:05:0", 
    "SFDC-User-Batch-3": "1:10:0", 
    "SFDC-User-Batch-4": "1:15:0" 
}; 
var fitbitapi = 'https://api.fitbit.com/1/user/-'; 
var checkConnectivity = "インタネットに接続できません、確認してください。"; 
var cameraMaxImageErrorMsg = "Cannot take more than 9 pictures"; 
var courseTitleErrorMsg = "コース名を入力してくさだい。"; 
var courseDescErrorMsg = "コメントを入力してください。"; 
var pedometerErrorMsg = "ステップセンサーがありません。"; 
var registeredCourseErrorMsg = "エラーが発生したためしばらくたってから登録してください。"; 
var viewregisteredCourseErrorMsg = "エラーが発生したためしばらくたってから登録してください。"; 
var walkMapDestinationError = "到着地点を入力してください"; //"Please enter the destination place"; 
var walkMapSourceError = "出発地点を入力してください"; //"Please enter the source place"; 
var unknownerror = "サーバ接続できません。しばらくたってからやり直しててください。"; 
  
var nicknamenotempty = "ニックネームを入力してください。"; //"Nick name should not be empty"; 
var entertargetsteps = "目標歩数を入力してください。"; //"Enter the target steps"; 
var emailmandatory = "Emailは必須項目です。"; //Email is mandatory 
var invalidemail = "無効なEmailです。"; //Invalid Email 
var nicknameMandatory = "ニックネームは必須項目です。"; //Nick name is mandatory 
var selectGender = "性別を選択してください。"; //Select the gender 
var yobMandatory = "生年は必須項目です。"; //Year of Birth is mandatory 
var invalidYob = "無効な生年です。"; //Invalid Year of Birth 
var pleaseAgreeTerms = "利用規約に承諾してください。"; //Please agree to the Terms and Conditions 
var notauthorizedwithGooglefit = "Googlefitを使用する権限がありません。"; //You are not authorized with googlefit 
var googlefitActivated = "Googlefitが使用できます。"; //GoogleFit is activated 
var gpsAccuracyError = "GPS信号に問題があります、継続しますか。"; 
var gpsErrorTitle = "GPS信号に問題があります。"; 
var continueTxt = "継続"; 
var cancelTxt  ="キャンセル"; 
var sourcechangewarning = "デバイスの変更をされる場合、変更前のデバイスの変更日の記録は消去され、新しいデバイスのデータに上書きされます（変更日以前のデータは変更前のデバイスのまま保持されます）。\r\nまた、デバイスの変更は1日1回のみ可能です。\r\nデバイスを変更しますか？"; 
var sourcechangenotpermit = "デバイスの変更は1日1回のみです。\r\n明日以降、ご変更ください"; 
var existinguser = "Login Successful for existing user"; 
var existinguserdifferentdeviceId = "Login Successful and device Id updated for existing user"; 
var wellnesTabLink = "http://wellnesslab.manulife.co.jp/walk/"; 
var alreadyacquired = "くつの寄付が完了しています！"; 
var alreadyacompaniedsource = "すでに連携しています"; 
var geolocationPermissionError = "本アプリにロケーションサービスをONにしてないです。ロケーションサービスをONにしてください。";
var facebookToastMsg = "クリップボードの情報をペストしてください。";
var courseRecordingStart= "出発地";
var PedometerPermissionError= "Motion & Fitness services are disabled for Manuwalk. You must enable Motion & Fitness Services for the Manuwalk app specifically in the Settings";